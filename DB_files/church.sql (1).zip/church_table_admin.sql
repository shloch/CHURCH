
-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `login` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `login`, `password`) VALUES
(1, 'shloch', 'e2fb38709b3798a60df51a9a6553af1f'),
(2, 'huguette', '4f6c9037932633681ccdafa8209803ad'),
(3, 'ateschrist', '02d3f3e059bab17795e22520c658310b');
