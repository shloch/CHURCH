
-- --------------------------------------------------------

--
-- Table structure for table `acceuil`
--

DROP TABLE IF EXISTS `acceuil`;
CREATE TABLE `acceuil` (
  `id` tinyint(4) NOT NULL,
  `derniere_infos` text NOT NULL,
  `recruitement` text NOT NULL,
  `repetitions` text NOT NULL,
  `nous_chantons` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acceuil`
--

INSERT INTO `acceuil` (`id`, `derniere_infos`, `recruitement`, `repetitions`, `nous_chantons`) VALUES
(1, '\"Shy Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. xxx\" ', '  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliquaxx.  ', '  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliquaxx.  ', '  TLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim venixx.    ');
