
-- --------------------------------------------------------

--
-- Table structure for table `chants_evenement`
--

DROP TABLE IF EXISTS `chants_evenement`;
CREATE TABLE `chants_evenement` (
  `id` int(11) NOT NULL,
  `nom_chant` varchar(300) NOT NULL,
  `reference` varchar(300) NOT NULL DEFAULT '0',
  `cdo_page` varchar(300) NOT NULL DEFAULT '0',
  `cdo_nr` varchar(300) NOT NULL DEFAULT '0',
  `mp3` varchar(300) NOT NULL DEFAULT '0',
  `calenderID` int(11) NOT NULL,
  `derouelementID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `chants_evenement`
--

INSERT INTO `chants_evenement` (`id`, `nom_chant`, `reference`, `cdo_page`, `cdo_nr`, `mp3`, `calenderID`, `derouelementID`) VALUES
(1, 'VIERGE MARIE', '0', '0', '0', '0', 9, 17),
(5, 'first song', '34377c57fbf7ebdc7926a3250121370c.txt', '0', '0', '0', 9, 18),
(6, 'hein hein', '0', '0', '0', '0', 9, 17),
(9, 'Hakeem', '0', '0', '0', '0', 11, 20);
