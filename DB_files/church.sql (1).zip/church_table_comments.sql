
-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `comment_date` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
