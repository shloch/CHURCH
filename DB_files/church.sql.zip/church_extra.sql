
--
-- Indexes for dumped tables
--

--
-- Indexes for table `acceuil`
--
ALTER TABLE `acceuil`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activites_choral`
--
ALTER TABLE `activites_choral`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `calender_evenement`
--
ALTER TABLE `calender_evenement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chants_evenement`
--
ALTER TABLE `chants_evenement`
  ADD PRIMARY KEY (`id`),
  ADD KEY `derouelementID` (`derouelementID`) USING BTREE,
  ADD KEY `calenderID` (`calenderID`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deroulement_evenement`
--
ALTER TABLE `deroulement_evenement`
  ADD PRIMARY KEY (`id`),
  ADD KEY `calenderID` (`calenderID`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `il_en_parlent`
--
ALTER TABLE `il_en_parlent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notre_equipe`
--
ALTER TABLE `notre_equipe`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acceuil`
--
ALTER TABLE `acceuil`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `activites_choral`
--
ALTER TABLE `activites_choral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `calender_evenement`
--
ALTER TABLE `calender_evenement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `chants_evenement`
--
ALTER TABLE `chants_evenement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deroulement_evenement`
--
ALTER TABLE `deroulement_evenement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `il_en_parlent`
--
ALTER TABLE `il_en_parlent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notre_equipe`
--
ALTER TABLE `notre_equipe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chants_evenement`
--
ALTER TABLE `chants_evenement`
  ADD CONSTRAINT `chants_evenement_ibfk_2` FOREIGN KEY (`derouelementID`) REFERENCES `deroulement_evenement` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `chants_evenement_ibfk_3` FOREIGN KEY (`calenderID`) REFERENCES `calender_evenement` (`id`);
