
-- --------------------------------------------------------

--
-- Table structure for table `il_en_parlent`
--

DROP TABLE IF EXISTS `il_en_parlent`;
CREATE TABLE `il_en_parlent` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `msg` varchar(2000) NOT NULL,
  `photo_url` varchar(300) NOT NULL DEFAULT 'NONE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `il_en_parlent`
--

INSERT IGNORE INTO `il_en_parlent` (`id`, `nom`, `role`, `msg`, `photo_url`) VALUES
(5, 'Aelred', 'Membre', 'La famille, ma famille. C\'est elle qui m\'a accueillie et m\'a aidé à grandir. Dans les moments de joie comme dans les moments de peine, mes frères et sœurs sont en Jésus, ce chant d\'espoir qui ne s\'éteint pas. La force de ma famille n\'est certainement pas le lien de sang, mais cette ardente prière, cette douce mélodie qui nous transforme et nous transporte vers notre Père Céleste; ces souvenirs de chaque moment passé les uns près des autres. OUI JE SUIS LWANGA - KISITO et même après ma mort je le serai toujours. Tel est mon Credo, telle est ma Profession de Foi.', '6fe145c045483047c38a7b146547e2d9.png');
