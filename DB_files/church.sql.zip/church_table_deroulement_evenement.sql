
-- --------------------------------------------------------

--
-- Table structure for table `deroulement_evenement`
--

DROP TABLE IF EXISTS `deroulement_evenement`;
CREATE TABLE `deroulement_evenement` (
  `id` int(11) NOT NULL,
  `forme_ordinaire` varchar(300) NOT NULL,
  `calenderID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `deroulement_evenement`
--

INSERT IGNORE INTO `deroulement_evenement` (`id`, `forme_ordinaire`, `calenderID`) VALUES
(1, 'MESSES  COMPLETES2', 0),
(2, ' BENEDICTION ', 0),
(9, 'SHLOCH444', 3),
(10, 'SHLooooch', 3),
(11, 'ppppppr', 10),
(14, 'SHLOCH4', 3),
(17, 'YOUPEEEEEE___9', 9),
(18, ' BENEDICTION ', 9);
