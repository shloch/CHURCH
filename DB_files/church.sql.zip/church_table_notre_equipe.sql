
-- --------------------------------------------------------

--
-- Table structure for table `notre_equipe`
--

DROP TABLE IF EXISTS `notre_equipe`;
CREATE TABLE `notre_equipe` (
  `id` int(11) NOT NULL,
  `nom` varchar(500) NOT NULL,
  `role` varchar(500) NOT NULL,
  `photo_url` varchar(1000) NOT NULL DEFAULT 'NONE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notre_equipe`
--

INSERT IGNORE INTO `notre_equipe` (`id`, `nom`, `role`, `photo_url`) VALUES
(128, 'Huguette L. Messomo', 'activité professionnelle en tant que qu\'Assistante de direction, membre de la chorale depuis 2011 et présidente depuis 2016', '35ae5cd1e76579f3dac4a12b69f10d8b.png'),
(129, 'Christophe Th ATANGANA ESSAH', 'membre de la chorale depuis 1992, organiste depuis 1994, maitre de chœur depuis 1998, Directeur technique depuis 2012.', 'NONE'),
(130, 'Eyenga Armelle', 'opératrice économique Membre active de lk depuis 1997. Trésoriere depuis le 14 octobre 2015', '0cdcd9fb0f6869a38dec1160a0f6150d.png'),
(131, 'MINALE claire Thérèse Maxime', 'enseignante, membre de la chorale depuis 2001, commissaire aux comptes depuis 2018', 'afb474893292b40f9c87f99f4abe17ad.png');
